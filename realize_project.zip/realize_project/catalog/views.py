from django.shortcuts import render
from .models import Projectreq
def index(request):
    num_projects = Projectreq.objects.all().count()
    context = {
        'num_projects': num_projects
    }
    return render(request, 'index.html', context=context)
# Create your views here.
