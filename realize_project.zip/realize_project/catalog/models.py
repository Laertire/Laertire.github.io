from django.db import models
from django.urls import reverse



# Create your models here.

class Prtag(models.Model):
    tg = models.CharField(max_length=200, help_text='Название вида работ')
 
    def __str__(self):
        """String for representing the Model object."""
        return self.tg

class Retag(models.Model):
    tg = models.CharField(max_length=200, help_text='Название вида работ')
 
    def __str__(self):
        """String for representing the Model object."""
        return self.tg

class Sutag(models.Model):
    tg = models.CharField(max_length=200, help_text='Название вида работ')
 
    def __str__(self):
        """String for representing the Model object."""
        return self.tg

class Projectreq(models.Model):

    vid = (
        ('p', 'Проектировка'),
        ('r', 'Производоство'),
        ('s', 'Закупка'),
    )

    tip = models.CharField(
        max_length=1,
        choices=vid,
        blank=True,
        default='p',
        help_text='Тип запроса',
    )

    if (tip =='p'):
     tag = models.ManyToManyField(Prtag)
    if (tip == 'r'):
     tag = models.ManyToManyField(Retag)
    if (tip =='s'):
     tag = models.ManyToManyField(Sutag)


    name = models.CharField(max_length=200)
    desc = models.TextField(max_length=1000)
    photo = models.ImageField()
    datedue = models.DateField()

    def __str__(self):
        """String for representing the Model object."""
        return self.name
