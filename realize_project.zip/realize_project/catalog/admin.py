from django.contrib import admin
from .models import Prtag, Retag, Sutag, Projectreq

admin.site.register(Prtag)
admin.site.register(Retag)
admin.site.register(Sutag)
admin.site.register(Projectreq)
# Register your models here.
